pi =3.14

def kerulet(r):
    return 2 * r * pi

def terulet(r):
    return r ** 2 * pi