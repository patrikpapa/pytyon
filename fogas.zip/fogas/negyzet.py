def kerulet(a):
    return 4 * a

def terulet(a):
    return a ** 2