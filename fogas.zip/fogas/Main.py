from kor import kerulet as k_kerulet, terulet as k_terulet
from negyzet import kerulet, terulet

print(f'Kör kerülete: {k_kerulet(10)}:.2f')
print(f'Kör területe: {k_terulet(10)}:.2f')

print(f'Négyzet kerülete: {kerulet(10)}:.2f')
print(f'Négyzet területe: {terulet(10)}:.2f')